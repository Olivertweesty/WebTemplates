<!doctype html>
<html lang="en-GB">
<head>
	<meta charset="UTF-8" />
	<meta name="viewport" content="width=device-width, initial-scale=1" />
	<link rel="profile" href="https://gmpg.org/xfn/11" />
	<title>Page not found &#8211; Themexexpert</title>
<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="Themexexpert &raquo; Feed" href="http://themexexpert.com/index.php/feed/" />
<link rel="alternate" type="application/rss+xml" title="Themexexpert &raquo; Comments Feed" href="http://themexexpert.com/index.php/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11.2.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/11.2.0\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/themexexpert.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.1.1"}};
			!function(a,b,c){function d(a,b){var c=String.fromCharCode;l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,a),0,0);var d=k.toDataURL();l.clearRect(0,0,k.width,k.height),l.fillText(c.apply(this,b),0,0);var e=k.toDataURL();return d===e}function e(a){var b;if(!l||!l.fillText)return!1;switch(l.textBaseline="top",l.font="600 32px Arial",a){case"flag":return!(b=d([55356,56826,55356,56819],[55356,56826,8203,55356,56819]))&&(b=d([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]),!b);case"emoji":return b=d([55358,56760,9792,65039],[55358,56760,8203,9792,65039]),!b}return!1}function f(a){var c=b.createElement("script");c.src=a,c.defer=c.type="text/javascript",b.getElementsByTagName("head")[0].appendChild(c)}var g,h,i,j,k=b.createElement("canvas"),l=k.getContext&&k.getContext("2d");for(j=Array("flag","emoji"),c.supports={everything:!0,everythingExceptFlag:!0},i=0;i<j.length;i++)c.supports[j[i]]=e(j[i]),c.supports.everything=c.supports.everything&&c.supports[j[i]],"flag"!==j[i]&&(c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&c.supports[j[i]]);c.supports.everythingExceptFlag=c.supports.everythingExceptFlag&&!c.supports.flag,c.DOMReady=!1,c.readyCallback=function(){c.DOMReady=!0},c.supports.everything||(h=function(){c.readyCallback()},b.addEventListener?(b.addEventListener("DOMContentLoaded",h,!1),a.addEventListener("load",h,!1)):(a.attachEvent("onload",h),b.attachEvent("onreadystatechange",function(){"complete"===b.readyState&&c.readyCallback()})),g=c.source||{},g.concatemoji?f(g.concatemoji):g.wpemoji&&g.twemoji&&(f(g.twemoji),f(g.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://themexexpert.com/wp-includes/css/dist/block-library/style.min.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-theme-css'  href='http://themexexpert.com/wp-includes/css/dist/block-library/theme.min.css?ver=5.1.1' type='text/css' media='all' />
<link rel='stylesheet' id='twentynineteen-style-css'  href='http://themexexpert.com/wp-content/themes/twentynineteen/style.css?ver=1.3' type='text/css' media='all' />
<link rel='stylesheet' id='twentynineteen-print-style-css'  href='http://themexexpert.com/wp-content/themes/twentynineteen/print.css?ver=1.3' type='text/css' media='print' />
<link rel='https://api.w.org/' href='http://themexexpert.com/index.php/wp-json/' />
<link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://themexexpert.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://themexexpert.com/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.1.1" />
		<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style>
		</head>

<body class="error404 wp-embed-responsive hfeed image-filters-enabled">
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content">Skip to content</a>

		<header id="masthead" class="site-header">

			<div class="site-branding-container">
				<div class="site-branding">

								<p class="site-title"><a href="http://themexexpert.com/" rel="home">Themexexpert</a></p>
			
				<p class="site-description">
				Just another WordPress site			</p>
			</div><!-- .site-branding -->
			</div><!-- .layout-wrap -->

					</header><!-- #masthead -->

	<div id="content" class="site-content">

	<section id="primary" class="content-area">
		<main id="main" class="site-main">

			<div class="error-404 not-found">
				<header class="page-header">
					<h1 class="page-title">Oops! That page can&rsquo;t be found.</h1>
				</header><!-- .page-header -->

				<div class="page-content">
					<p>It looks like nothing was found at this location. Maybe try a search?</p>
					<form role="search" method="get" class="search-form" action="http://themexexpert.com/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form>				</div><!-- .page-content -->
			</div><!-- .error-404 -->

		</main><!-- #main -->
	</section><!-- #primary -->


	</div><!-- #content -->

	<footer id="colophon" class="site-footer">
		
	<aside class="widget-area" role="complementary" aria-label="Footer">
							<div class="widget-column footer-widget-1">
					<section id="search-2" class="widget widget_search"><form role="search" method="get" class="search-form" action="http://themexexpert.com/">
				<label>
					<span class="screen-reader-text">Search for:</span>
					<input type="search" class="search-field" placeholder="Search &hellip;" value="" name="s" />
				</label>
				<input type="submit" class="search-submit" value="Search" />
			</form></section>		<section id="recent-posts-2" class="widget widget_recent_entries">		<h2 class="widget-title">Recent Posts</h2>		<ul>
											<li>
					<a href="http://themexexpert.com/index.php/2019/03/28/hello-world/">Hello world!</a>
									</li>
					</ul>
		</section><section id="recent-comments-2" class="widget widget_recent_comments"><h2 class="widget-title">Recent Comments</h2><ul id="recentcomments"><li class="recentcomments"><span class="comment-author-link"><a href='https://wordpress.org/' rel='external nofollow' class='url'>A WordPress Commenter</a></span> on <a href="http://themexexpert.com/index.php/2019/03/28/hello-world/#comment-1">Hello world!</a></li></ul></section><section id="archives-2" class="widget widget_archive"><h2 class="widget-title">Archives</h2>		<ul>
				<li><a href='http://themexexpert.com/index.php/2019/03/'>March 2019</a></li>
		</ul>
			</section><section id="categories-2" class="widget widget_categories"><h2 class="widget-title">Categories</h2>		<ul>
				<li class="cat-item cat-item-1"><a href="http://themexexpert.com/index.php/category/uncategorised/" >Uncategorised</a>
</li>
		</ul>
			</section><section id="meta-2" class="widget widget_meta"><h2 class="widget-title">Meta</h2>			<ul>
						<li><a href="http://themexexpert.com/wp-login.php">Log in</a></li>
			<li><a href="http://themexexpert.com/index.php/feed/">Entries <abbr title="Really Simple Syndication">RSS</abbr></a></li>
			<li><a href="http://themexexpert.com/index.php/comments/feed/">Comments <abbr title="Really Simple Syndication">RSS</abbr></a></li>
			<li><a href="https://wordpress.org/" title="Powered by WordPress, state-of-the-art semantic personal publishing platform.">WordPress.org</a></li>			</ul>
			</section>					</div>
					</aside><!-- .widget-area -->

		<div class="site-info">
										<a class="site-name" href="http://themexexpert.com/" rel="home">Themexexpert</a>,
						<a href="https://en-gb.wordpress.org/" class="imprint">
				Proudly powered by WordPress.			</a>
								</div><!-- .site-info -->
	</footer><!-- #colophon -->

</div><!-- #page -->

<script type='text/javascript' src='http://themexexpert.com/wp-includes/js/wp-embed.min.js?ver=5.1.1'></script>
	<script>
	/(trident|msie)/i.test(navigator.userAgent)&&document.getElementById&&window.addEventListener&&window.addEventListener("hashchange",function(){var t,e=location.hash.substring(1);/^[A-z0-9_-]+$/.test(e)&&(t=document.getElementById(e))&&(/^(?:a|select|input|button|textarea)$/i.test(t.tagName)||(t.tabIndex=-1),t.focus())},!1);
	</script>
	
</body>
</html>
